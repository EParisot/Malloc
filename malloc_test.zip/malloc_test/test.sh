#!/usr/bin/env bash
source srcs/include.sh
parse_args $@
init
run_with_arg
run