#!/usr/bin/env bash

source `pwd`/srcs/variable.sh
source `pwd`/srcs/function.sh
source `pwd`/srcs/test_function.sh
source `pwd`/srcs/run_function.sh